package com.config.docs;

import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;


@Configuration
public class SwaggerConfig {

	@Bean
	OpenAPI drawerOpenAPI() {
		return new OpenAPI()
			.info(new Info()
				.title("그림판")
				.description("JSON 기반 그림판 API")
				.version("v1.0.0")
				.license(new License().name("Apache 2.0").url("http://springdoc.org")));
	}
}

