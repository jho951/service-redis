//package com.user.service;
//
//import java.util.UUID;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.stereotype.Service;
//
//import com.user.config.JwtProvider;
//import com.user.domain.User;
//import com.user.dto.RequestDto;
//import com.user.dto.ResponseDto;
//import com.user.repository.UserMapper;
//
//import lombok.RequiredArgsConstructor;
//
//@Service
//@RequiredArgsConstructor
//public class UserService {
//	private final UserMapper userMapper;
//	private final JwtProvider jwt;
//	private final BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
//
//	public ResponseDto.login login(RequestDto.login req) {
//		User u = userMapper.findByEmail(req.email())
//			.orElseThrow(() -> new RuntimeException("존재하지 않는 계정"));
//		if (!encoder.matches(req.password(), u.getPasswordHash()))
//			throw new RuntimeException("비밀번호 불일치");
//
//		String at = jwt.createAccess(u.getEmail(), u.getRole());
//		String rt = jwt.createRefresh(u.getEmail());
//		return new ResponseDto.login(at, rt);
//	}
//
//	public void signup(String email, String rawPw, String role) {
//		User u = User.builder()
//			.id(UUID.randomUUID())
//			.email(email)
//			.passwordHash(encoder.encode(rawPw))
//			.role(role == null ? "ROLE_USER" : role)
//			.build();
//		userMapper.insertUser(u);
//	}
//}
