//package com.user.repository;
//import java.util.Optional;
//import org.apache.ibatis.annotations.Mapper;
//import org.apache.ibatis.annotations.Param;
//
//import com.user.domain.User;
//
//@Mapper
//public interface UserMapper {
//	Optional<User> findByEmail(@Param("email") String email);
//	int insertUser(User user);
//}
