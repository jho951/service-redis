//package com.user.config;
//
//import java.io.IOException;
//import java.util.List;
//
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.http.HttpMethod;
//import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
//import org.springframework.security.config.Customizer;
//import org.springframework.security.config.annotation.web.builders.HttpSecurity;
//import org.springframework.security.core.authority.SimpleGrantedAuthority;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.security.web.SecurityFilterChain;
//import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
//import jakarta.servlet.*;
//import jakarta.servlet.http.*;
//import lombok.RequiredArgsConstructor;
//
//@Configuration
//@RequiredArgsConstructor
//public class SecurityConfig {
//
//	private final JwtProvider jwt;
//
//	@Bean
//	SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//		http
//			.csrf(csrf -> csrf.disable())
//			.cors(Customizer.withDefaults())
//			.sessionManagement(sm -> sm.sessionCreationPolicy(
//				org.springframework.security.config.http.SessionCreationPolicy.STATELESS))
//			.authorizeHttpRequests(auth -> auth
//				.requestMatchers("/api/auth/**").permitAll()
//				.requestMatchers(HttpMethod.GET, "/api/drawings/**").permitAll()  // 예: 조회는 공개
//				.anyRequest().authenticated()
//			)
//			.addFilterBefore(new JwtFilter(jwt), UsernamePasswordAuthenticationFilter.class);
//		return http.build();
//	}
//
//	static class JwtFilter implements Filter {
//		private final JwtProvider jwt;
//		JwtFilter(JwtProvider jwt){ this.jwt = jwt; }
//		@Override public void doFilter(ServletRequest r, ServletResponse s, FilterChain c)
//			throws IOException, ServletException {
//			HttpServletRequest req = (HttpServletRequest) r;
//			String h = req.getHeader("Authorization");
//			if (h != null && h.startsWith("Bearer ")) {
//				String token = h.substring(7);
//				try {
//					var jws = jwt.parse(token);
//					String email = jws.getBody().getSubject();
//					String role  = (String) jws.getBody().get("role");
//					var auth = new UsernamePasswordAuthenticationToken(
//						email, null, List.of(new SimpleGrantedAuthority(role)));
//					SecurityContextHolder.getContext().setAuthentication(auth);
//				} catch (Exception ignore) {}
//			}
//			c.doFilter(r, s);
//		}
//	}
//}
