//package com.user.config;
//
//import java.util.Date;
//import java.util.Map;
//import javax.crypto.spec.SecretKeySpec;
//import io.jsonwebtoken.*;
//import io.jsonwebtoken.security.Keys;
//import org.springframework.beans.factory.annotation.Value;
//import org.springframework.stereotype.Component;
//
//@Component
//public class JwtProvider {
//	private final byte[] secretBytes;
//	private final long accessMs;
//	private final long refreshMs;
//
//	public JwtProvider(
//		@Value("${auth.jwt.secret}") String secret,
//		@Value("${auth.jwt.access-exp-min}") long accessMin,
//		@Value("${auth.jwt.refresh-exp-days}") long refreshDays
//	) {
//		this.secretBytes = secret.getBytes();
//		this.accessMs = accessMin * 60_000L;
//		this.refreshMs = refreshDays * 24 * 60 * 60_000L;
//	}
//
//	private JwtBuilder base(Map<String,Object> claims, String subject, long ttlMs) {
//		long now = System.currentTimeMillis();
//		return Jwts.builder()
//			.setClaims(claims)
//			.setSubject(subject)
//			.setIssuedAt(new Date(now))
//			.setExpiration(new Date(now + ttlMs))
//			.signWith(new SecretKeySpec(secretBytes, SignatureAlgorithm.HS256.getJcaName()));
//	}
//
//	public String createAccess(String sub, String role) {
//		return base(Map.of("role", role), sub, accessMs).compact();
//	}
//	public String createRefresh(String sub) {
//		return base(Map.of("type","refresh"), sub, refreshMs).compact();
//	}
//
//	public Jws<Claims> parse(String token) {
//		return Jwts.parserBuilder()
//			.setSigningKey(Keys.hmacShaKeyFor(secretBytes))
//			.build()
//			.parseClaimsJws(token);
//	}
//}
