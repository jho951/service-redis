//package com.user.controller;
//
//import org.springframework.http.*;
//import org.springframework.web.bind.annotation.*;
//
//import com.common.web.ApiResponse;
//import com.user.dto.RequestDto;
//import com.user.dto.ResponseDto;
//import com.user.service.UserService;
//
//import lombok.RequiredArgsConstructor;
//
//@RestController
//@RequestMapping("/api/auth")
//@RequiredArgsConstructor
//public class UserController {
//	private final UserService auth;
//
//	@PostMapping("/login")
//	public ResponseEntity<ApiResponse<ResponseDto.login>> login(@RequestBody RequestDto.login req) {
//		var res = auth.login(req);
//		return ResponseEntity.ok(ApiResponse.success(HttpStatus.OK, "ok", "/api/auth/login", res));
//	}
//
//}
