package com.user.domain;

import java.util.UUID;

import com.common.domain.BaseEntity;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class User extends BaseEntity {
	@ToString.Include
	@EqualsAndHashCode.Include
	private UUID id;
	private String email;
	private String passwordHash;
	private String role;
}