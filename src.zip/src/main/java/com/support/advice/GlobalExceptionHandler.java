package com.support.advice;



import com.common.error.AppException;
import com.common.error.ErrorCode;
import com.common.web.ApiResponse;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(AppException.class)
    public ResponseEntity<ApiResponse<Void>> handleApp(AppException e, HttpServletRequest req) {
        var code = e.getErrorCode();
        return ResponseEntity
                .status(code.httpStatus())
                .body(ApiResponse.error(code, e.getMessage(), req.getRequestURI()));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiResponse<Void>> handleAny(Exception e, HttpServletRequest req) {
        var code = ErrorCode.BAD_REQUEST;
        return ResponseEntity
                .status(code.httpStatus())
                .body(ApiResponse.error(code, e.getMessage(), req.getRequestURI()));
    }
}
