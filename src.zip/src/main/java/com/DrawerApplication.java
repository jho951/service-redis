package com;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.drawer.infrastructure.mapper")
public class DrawerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DrawerApplication.class, args);
	}
}
