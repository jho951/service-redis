package com.drawer.application;

import com.common.error.AppException;
import com.common.error.ErrorCode;
import com.drawer.config.VectorJsonDefaults;
import com.drawer.config.VectorJsonValidator;
import com.drawer.domain.Drawer;
import com.drawer.domain.Payload;
import com.drawer.infrastructure.mapper.DrawerMapper;
import com.drawer.interfaces.dto.request.RequestDto;
import com.drawer.interfaces.dto.response.ResponseDto;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class DrawerService {

    private final ObjectMapper objectMapper;
    private final DrawerMapper mapper;
    private final VectorJsonDefaults defaults;
    private final VectorJsonValidator validator;


    @Transactional
    public UUID postDrawer(RequestDto.postDrawer req) {
        final String title = req.title();
        final Object raw = req.vectorJson();
        final UUID id = UUID.randomUUID();

        if (title == null || title.isBlank())
            throw new AppException(ErrorCode.BAD_REQUEST, "제목은 필수입니다.");

        if (mapper.existsTitle(title))
            throw new AppException(ErrorCode.DUPLICATED_TITLE, "같은 이름이 존재합니다. " + title);

        final String vectorJsonStr;
        try {
            if (raw == null) {
                vectorJsonStr = defaults.asString();
            } else if (raw instanceof String s) {
                objectMapper.readTree(s); // JSON 유효성만 확인
                vectorJsonStr = s;
            } else {
                vectorJsonStr = objectMapper.writeValueAsString(raw);
            }
        } catch (JsonProcessingException e) {
            throw new AppException(ErrorCode.BAD_REQUEST, "vectorJson이 올바른 JSON이 아닙니다.");
        }

        validator.validateOrThrow(vectorJsonStr);

        Drawer d = new Drawer();
        d.setId(id);
        d.setTitle(title);
        d.setVersion(0);
        if (mapper.insertMeta(d) != 1)
            throw new AppException(ErrorCode.BAD_REQUEST, "메타 저장에 실패했습니다.");

        Payload p = new Payload();
        p.setId(id);
        p.setVectorJson(vectorJsonStr);
        if (mapper.insertPayload(p) != 1)
            throw new AppException(ErrorCode.BAD_REQUEST, "페이로드 저장에 실패했습니다.");

        return id;
    }


    @Transactional(readOnly = true)
    public ResponseDto.getDrawer getDrawer(UUID id) {
        Drawer d = mapper.findByIdWithPayload(id)
                .orElseThrow(() -> new AppException(ErrorCode.DRAWING_NOT_FOUND, "존재하지 않거나 삭제된 Drawer 입니다. " + id));
        String vectorJson = (d.getPayload() != null) ? d.getPayload().getVectorJson() : null;
        return new ResponseDto.getDrawer(
                d.getId(), d.getTitle(),
                d.getCreatedAt(), d.getUpdatedAt(), d.getDeletedAt(),
                d.getVersion(), vectorJson
        );
    }


    @Transactional(readOnly = true)
    public ResponseDto.page<ResponseDto.getDrawerList> getDrawerList(int limit, int offset, boolean deleted) {
        limit  = Math.max(1, Math.min(limit, 200));
        offset = Math.max(0, offset);

        List<Drawer> items = deleted ? mapper.findDeletedPage(limit, offset)
                : mapper.findPage(limit, offset);
        long total = deleted ? mapper.deletedCount() : mapper.count();

        var rows = items.stream().map(ResponseDto.getDrawerList::from).toList();
        return ResponseDto.page.of(total, limit, offset, rows);
    }

    @Transactional
    public ResponseDto.putDrawer putDrawer(UUID id, RequestDto.putDrawer req) {
        final String title = req.title();
        final Object raw = req.vectorJson();

        if (mapper.existsTitleOther(id, title)) {
            throw new AppException(ErrorCode.DUPLICATED_TITLE, "같은 이름이 존재합니다. " + title);
        }

        final String vectorJsonStr;
        try {
            if (raw == null) {
                vectorJsonStr = new String(defaults.asString());
            } else if (raw instanceof String s) {
                objectMapper.readTree(s);
                vectorJsonStr = s;
            } else {
                vectorJsonStr = objectMapper.writeValueAsString(raw);
            }
        } catch (JsonProcessingException e) {
            throw new AppException(ErrorCode.BAD_REQUEST, "vectorJson이 올바른 JSON이 아닙니다.");
        }
        validator.validateOrThrow(vectorJsonStr);

        int updatedTitle = mapper.updateDrawerTitle(id, title);
        if (updatedTitle == 0) {
            throw new AppException(ErrorCode.DRAWING_NOT_FOUND, "버전 불일치 " + id);
        }

        int updatedPayload = mapper.updatePayload(id, vectorJsonStr);
        if (updatedPayload == 0) {
            mapper.insertPayload(new Payload(id, vectorJsonStr));
        }

        Drawer d = mapper.findByIdWithPayload(id)
                .orElseThrow(() -> new AppException(ErrorCode.DRAWING_NOT_FOUND, "존재하지 않거나 삭제된 Drawer 입니다. " + id));

        return ResponseDto.putDrawer.from(d);
    }


    @Transactional
    public void deleteSoft(UUID id) {
        int updated = mapper.softDelete(id);
        if (updated == 0) {
            throw new AppException(ErrorCode.DRAWING_NOT_FOUND, "존재하지 않거나 삭제된 Drawer 입니다. " + id);
        }
    }

    @Transactional
    public void restore(UUID id) {
        int updated = mapper.restore(id);
        if (updated == 0) {
            throw new AppException(ErrorCode.DRAWING_NOT_DELETED, "삭제 상태가 아니거나 존재하지 않습니다. " + id);
        }
    }


    @Transactional
    public void deleteHard(UUID id) {
        mapper.deletePayloadByDrawerId(id);
        int n = mapper.deleteDrawer(id);
        if (n == 0) {
            throw new AppException(ErrorCode.DRAWING_NOT_FOUND, "존재하지 않거나 이미 삭제된 Drawer 입니다. " + id);
        }
    }

    @Transactional(readOnly = true)
    public Long count() {
        return mapper.count();
    }
}
