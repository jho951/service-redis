package com.drawer.application;

import com.common.error.ErrorCode;
import com.common.error.AppException;
import com.drawer.domain.Drawer;
import com.drawer.domain.Payload;
import com.drawer.infrastructure.mapper.DrawerMapper;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.networknt.schema.JsonSchema;
import com.networknt.schema.ValidationMessage;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DrawerImportService {

    private final DrawerMapper mapper;
    private final ObjectMapper om;
    private final JsonSchema vectorDocSchema;

    /** 컨트롤러에 의존하지 않는 내부 DTO */
    public record Imported(UUID id, String title, Integer version) {}

    /**
     * 전달된 vectorJson을 검증 후 Drawer/ Payload로 저장
     * @param vectorJson 필수 JSON 문자열
     * @param titleHint  null이면 meta.title 또는 "Imported {now}"
     */
    @Transactional
    public Imported saveFromVectorJson(String vectorJson, String titleHint) {
        if (vectorJson == null || vectorJson.isBlank())
            throw new AppException(ErrorCode.BAD_REQUEST, "vectorJson이 비었습니다.");

        JsonNode node;
        try {
            node = om.readTree(vectorJson);
        } catch (Exception e) {
            throw new AppException(ErrorCode.BAD_REQUEST, "vectorJson 파싱 실패");
        }

        Set<ValidationMessage> errors = vectorDocSchema.validate(node);
        if (!errors.isEmpty()) {
            String msg = errors.stream()
                    .limit(3)
                    .map(ValidationMessage::getMessage)
                    .collect(Collectors.joining("; "));
            throw new AppException(ErrorCode.BAD_REQUEST, "스키마 검증 실패: " + msg);
        }

        // 제목: hint > json.meta.title > 기본값
        String title = Optional.ofNullable(titleHint).orElseGet(() ->
                Optional.ofNullable(node.path("meta").path("title").asText(null))
                        .orElse("Imported " + java.time.LocalDateTime.now())
        );

        UUID id = UUID.randomUUID();
        int version = 0;

        Drawer d = new Drawer();
        d.setId(id);
        d.setTitle(title);
        d.setVersion(version);
        mapper.insertMeta(d);

        Payload p = new Payload();
        p.setId(id);
        p.setVectorJson(vectorJson);
        mapper.insertPayload(p);

        return new Imported(id, title, version);
    }
}
