package com.drawer.interfaces.api;

import com.common.error.ErrorCode;
import com.common.web.ApiResponse;
import com.common.error.AppException;
import com.drawer.infrastructure.mapper.DrawerMapper;
import com.drawer.application.DrawerImportService;

import lombok.RequiredArgsConstructor;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.*;

@RestController
@RequestMapping("/api/drawings")
@RequiredArgsConstructor
public class DrawerImportController {

    private final DrawerMapper mapper;
    private final DrawerImportService drawerImportService;

    /**
     * payload 시트 포맷:
     * A열: drawer_id(옵션), B열: vectorJson(필수)
     * mode: auto | single (auto는 행 수에 따라 자동 분기)
     */
    @PostMapping(path = "/import.xlsx", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<ApiResponse<Map<String, Object>>> importFromExcel(
            @RequestPart("file") MultipartFile file,
            @RequestParam(defaultValue = "auto") String mode
    ) {
        if (file.isEmpty()) throw new AppException(ErrorCode.BAD_REQUEST, "파일이 비었습니다.");

        try (InputStream in = file.getInputStream();
             XSSFWorkbook wb = new XSSFWorkbook(in)) {

            Sheet payload = wb.getSheet("payload");
            if (payload == null)
                throw new AppException(ErrorCode.BAD_REQUEST, "payload 시트를 찾을 수 없습니다.");
            if (payload.getLastRowNum() < 1)
                throw new AppException(ErrorCode.BAD_REQUEST, "payload 시트에 데이터가 없습니다.");

            List<DrawerImportService.Imported> imported = new ArrayList<>();

            boolean isSingle = "single".equalsIgnoreCase(mode)
                    || ("auto".equalsIgnoreCase(mode) && payload.getLastRowNum() <= 1);

            if (isSingle) {
                Row data = payload.getRow(1);
                if (data == null)
                    throw new AppException(ErrorCode.BAD_REQUEST, "payload 시트 2행이 없습니다.");
                String json = getString(data.getCell(1)); // B열
                DrawerImportService.Imported one = drawerImportService.saveFromVectorJson(json, null);
                imported.add(one);
            } else {
                for (int r = 1; r <= payload.getLastRowNum(); r++) {
                    Row row = payload.getRow(r);
                    if (row == null) continue;
                    String json = getString(row.getCell(1)); // B열
                    if (json == null || json.isBlank()) continue;
                    DrawerImportService.Imported it = drawerImportService.saveFromVectorJson(json, null);
                    imported.add(it);
                }
            }

            Map<String, Object> body = Map.of("count", imported.size(), "items", imported);
            return ResponseEntity.ok(ApiResponse.success(
                    HttpStatus.OK, "imported", "/api/drawings/import.xlsx", body));

        } catch (IOException e) {
            throw new AppException(ErrorCode.BAD_REQUEST, "엑셀 읽기 실패: " + e.getMessage());
        }
    }

    /* ----------------- helpers ----------------- */

    private static String getString(Cell c) {
        if (c == null) return null;
        return switch (c.getCellType()) {
            case STRING -> c.getStringCellValue();
            case NUMERIC -> new java.text.DecimalFormat("#.#############")
                    .format(c.getNumericCellValue());
            case BOOLEAN -> Boolean.toString(c.getBooleanCellValue());
            case FORMULA -> c.getCellFormula();
            default -> null;
        };
    }
}
