package com.drawer.interfaces.api;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.stream.Collectors;

import com.common.error.ErrorCode;

import com.common.error.AppException;
import com.drawer.domain.Drawer;
import com.drawer.domain.Payload;
import com.drawer.infrastructure.mapper.DrawerMapper;
import com.drawer.application.DrawerExportService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/drawings")
@RequiredArgsConstructor
public class DrawerExportController {

    private final DrawerMapper mapper;
    private final DrawerExportService drawerExportService;

    /** 1) 단일 Drawer 엑셀 다운로드 */
    @GetMapping("/{id}/export.xlsx")
    public ResponseEntity<byte[]> exportOne(@PathVariable UUID id) {
        Drawer d = mapper.findByIdWithPayload(id)
                .orElseThrow(() -> new AppException(
                        ErrorCode.DRAWING_NOT_FOUND,
                        "존재하지 않거나 삭제된 Drawer 입니다. " + id));

        byte[] bytes = drawerExportService.makeSingleWorkbook(d, d.getPayload());
        String filename = safeFileName(d.getTitle()) + ".xlsx";
        return attachment(bytes, filename);
    }

    /** 2) 현재 조건(페이지, 휴지통 여부) 목록을 엑셀로 다운로드 */
    // 예: /api/drawings/export.xlsx?page=1&size=100&deleted=true
    @GetMapping("/export.xlsx")
    public ResponseEntity<byte[]> exportList(
            @RequestParam(defaultValue = "1") int page,
            @RequestParam(defaultValue = "100") int size,
            @RequestParam(required = false) Boolean deleted
    ) {
        page = Math.max(page, 1);
        size = Math.min(Math.max(size, 1), 1000);

        // Mapper는 deleted 필터를 반영한 페이징 메서드를 사용하도록 권장
        List<Drawer> rows = mapper.findPage(page, size);

        // payload 포함이 필요하면 각 id로 조회하여 매핑
        Map<UUID, Payload> payloadMap = rows.stream()
                .map(d -> mapper.findPayloadById(d.getId()).orElse(null))
                .filter(Objects::nonNull)
                .collect(Collectors.toMap(Payload::getId, p -> p));

        byte[] bytes = drawerExportService.makeListWorkbook(rows, payloadMap);
        String filename = "drawings_export_p" + page + "_s" + size
                + ((deleted != null && deleted) ? "_deleted" : "") + ".xlsx";
        return attachment(bytes, filename);
    }

    /* ----------------- helpers ----------------- */

    private ResponseEntity<byte[]> attachment(byte[] bytes, String filename) {
        String encoded = URLEncoder.encode(filename, StandardCharsets.UTF_8)
                .replaceAll("\\+", "%20");
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.parseMediaType(
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        headers.setContentLength(bytes.length);
        headers.set(HttpHeaders.CONTENT_DISPOSITION,
                "attachment; filename*=UTF-8''" + encoded);
        return new ResponseEntity<>(bytes, headers, HttpStatus.OK);
    }

    private String safeFileName(String title) {
        String base = (title == null || title.isBlank()) ? "drawing" : title.trim();
        return base.replaceAll("[\\\\/:*?\"<>|]", "_");
    }
}
