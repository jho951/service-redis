package com.drawer.interfaces.api;

import java.util.UUID;

import com.drawer.application.DrawerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.common.web.ApiResponse;
import com.drawer.interfaces.dto.request.RequestDto;
import com.drawer.interfaces.dto.response.ResponseDto;

import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import jakarta.servlet.http.HttpServletRequest;

@Tag(name = "Drawing", description = "JSON CRUD")
@RestController
@RequestMapping(path = "/api/drawings", produces = "application/json")
@RequiredArgsConstructor
public class DrawerController {

    private final DrawerService drawerService;

    /**
     * 그림을 저장한다.
     * <p>
     * 		벡터 데이터를 drawer, payload 테이블에 저장
     * </p>
     * @version 1.0
     * @author YJH
     * @param 제목과 캔버스 벡터 데이터로 제목은 null 허용안됨
     * @param http
     * @return : 용량이 작아 실을 수 없었떤 제품,
     *           모두 실었다면 empty
     * @throws : 제품이 null -> NullPointException
     * @see : CargoShip#getRemainingCapacity()용량 확인하는 함수
     * @see : CargoShip#unload() 제품을 내리는 함수
     */
    @Operation(summary = "그림 저장")
    @PostMapping(consumes = "application/json")
    public ResponseEntity<ApiResponse<ResponseDto.idOnly>> postDrawer(
        @Valid @RequestBody RequestDto.postDrawer req,
        HttpServletRequest http
    ) {
 
        UUID id = drawerService.postDrawer(req);
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success(HttpStatus.CREATED, "created", http.getRequestURI(), new ResponseDto.idOnly(id)));
        
    }

    @Operation(summary = "단건 조회")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<ResponseDto.getDrawer>> getDrawer(
        @PathVariable UUID id, HttpServletRequest httpReq) {
        var body = drawerService.getDrawer(id);
        return ResponseEntity.ok(ApiResponse.success(HttpStatus.OK, "ok", httpReq.getRequestURI(), body));
    }

    @Operation(summary = "목록 조회")
    @GetMapping
    public ResponseEntity<ApiResponse<ResponseDto.page<ResponseDto.getDrawerList>>> getDrawerList(
        @RequestParam(defaultValue = "1") int page,
        @RequestParam(defaultValue = "20") int size,
        @RequestParam(defaultValue = "true") boolean deleted,
        HttpServletRequest req
    ) {
        int limit = Math.min(Math.max(size, 1), 200);
        int offset = (Math.max(page, 1) - 1) * limit;
        var pageRes = drawerService.getDrawerList(limit, offset,deleted);
        return ResponseEntity.ok()
            .header("X-Total-Count", String.valueOf(pageRes.total()))
            .body(ApiResponse.success(HttpStatus.OK, "ok", req.getRequestURI(), pageRes));
    }

    @Operation(summary = "수정")
    @PutMapping(path = "/{id}", consumes = "application/json")
    public ResponseEntity<ApiResponse<ResponseDto.putDrawer>> putDrawer(
        @PathVariable UUID id,
        @Valid @RequestBody RequestDto.putDrawer req,
        HttpServletRequest httpReq
    ) {
        ResponseDto.putDrawer body = drawerService.putDrawer(id, req);
        return ResponseEntity.ok(
            ApiResponse.success(HttpStatus.OK, "updated", httpReq.getRequestURI(), body)
        );
    }

    @Operation(summary = "복원")
    @PutMapping(path = "/{id}/restore")
    public ResponseEntity<ApiResponse<Void>> restore(
        @PathVariable UUID id,
        HttpServletRequest httpReq
    ) {
        drawerService.restore(id);
         return ResponseEntity.ok(ApiResponse.success(HttpStatus.OK, "restored", httpReq.getRequestURI(), null));
    }

    @Operation(summary = "삭제(기본: 소프트 삭제, 하드 삭제는 ?hard=true)")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse<Void>> delete(
        @PathVariable UUID id,
        @RequestParam(name = "hard", defaultValue = "false") boolean hard,
        HttpServletRequest httpReq
    ) {
        if (hard) {
            drawerService.deleteHard(id);
        } else {
            drawerService.softDelete(id);
        }
         return ResponseEntity.ok(ApiResponse.success(HttpStatus.OK, hard ? "deleted" : "soft_deleted", httpReq.getRequestURI(), null));
    }
}
