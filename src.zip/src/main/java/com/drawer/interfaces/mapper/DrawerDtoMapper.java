package com.drawer.interfaces.mapper;

import java.util.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import com.drawer.interfaces.dto.response.DrawerListItemResponse;

@Mapper
public interface DrawerMapper {

    // 목록 + 조건부 삭제필터
    List<DrawerListItemResponse> selectPage(
            @Param("offset") int offset,
            @Param("size") int size,
            @Param("deleted") Boolean deleted // null: 전체, true: 삭제만, false: 미삭제만
    );

    long count(@Param("deleted") Boolean deleted);

    // (기존 존재하던 메서드들은 그대로 유지: insertMeta, insertPayload, existsTitleOther 등)
}
