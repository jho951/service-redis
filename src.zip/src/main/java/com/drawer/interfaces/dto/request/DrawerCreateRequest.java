package com.drawer.interfaces.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;

@Schema(name = "DrawerCreateRequest", description = "그림 생성 요청 DTO")
@JsonInclude(JsonInclude.Include.NON_NULL)
public record DrawerCreateRequest(
        @Schema(description = "도면 제목", example = "Landing Page Sketch v1", maxLength = 255)
        @NotBlank
        String title,

        @Schema(
                description = "벡터 JSON, null이면 서버 기본 스켈레톤 적용 가능",
                implementation = Object.class,
                nullable = true
        )
        JsonNode vectorJson
) {}
