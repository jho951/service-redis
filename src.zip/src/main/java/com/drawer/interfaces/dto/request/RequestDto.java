package com.drawer.interfaces.dto.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.databind.JsonNode;
import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotBlank;


@Schema(name = "RequestDto", description = "도면 CRUD 요청 DTO 모음")
@JsonInclude(Include.NON_NULL)
public final class RequestDto {

    @Schema(name = "RequestDto.postDrawer", description = "도면 생성 요청 바디")
    public record postDrawer(
        @Schema(description = "도면 제목", example = "Landing Page Sketch v1", maxLength = 255)
        @NotBlank
        String title,

        @Schema(
            description = "벡터 JSON(자유 구조). null이면 서버 기본 스켈레톤 적용 가능",
            implementation = Object.class,
            nullable = true
        )
        JsonNode vectorJson
    ) {}

    @Schema(name = "RequestDto.putDrawer", description = "도면 수정 요청 바디")
    public record putDrawer(
        @Schema(description = "도면 제목", example = "Landing Page Sketch v2", maxLength = 255)
        @NotBlank
        String title,

        @Schema(
            description = "벡터 JSON(자유 구조). null이면 서버에서 기존 값 유지",
            implementation = Object.class,
            nullable = true
        )
        JsonNode vectorJson,

        @Schema(
            description = "낙관적 락용 버전(선택). 서버가 version 기반 업데이트를 할 때 사용",
            example = "2",
            nullable = true
        )
        Integer version
    ) {}
}
