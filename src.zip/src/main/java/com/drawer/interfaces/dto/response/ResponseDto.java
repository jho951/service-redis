package com.drawer.interfaces.dto.response;

import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

import com.drawer.domain.Drawer;

public class ResponseDto {

    public record idOnly(UUID id) {}

    public record getDrawer(
        UUID id,
        String title,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        LocalDateTime deletedAt,
        Integer version,
        String vectorJson
    ) {}

    public record getDrawerList(
        UUID id,
        String title,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        Integer version
    ) {
        public static getDrawerList from(Drawer d) {
            return new getDrawerList(
                d.getId(), d.getTitle(), d.getCreatedAt(), d.getUpdatedAt(), d.getVersion()
            );
        }
    }
    

    public record getDeletedDrawerList(
        UUID id,
        String title,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        LocalDateTime deletedAt
    ) {
        public static getDeletedDrawerList from(Drawer d) {
            return new getDeletedDrawerList(
                d.getId(), d.getTitle(), d.getCreatedAt(), d.getUpdatedAt(),d.getDeletedAt()
            );
        }
    }

    

    public record page<T>(long total, int limit, int offset, List<T> rows) {
        public static <T> page<T> of(long total, int limit, int offset, List<T> rows) {
            return new page<>(total, limit, offset, rows);
        }
    }

    public record putDrawer(
        UUID id, String title, Integer version, LocalDateTime updatedAt
    ) {
        public static putDrawer from(Drawer d) {
            return new putDrawer(d.getId(), d.getTitle(), d.getVersion(), d.getUpdatedAt());
        }
    }
}
