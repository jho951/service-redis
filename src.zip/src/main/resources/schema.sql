CREATE TABLE IF NOT EXISTS drawer (
  id BINARY(16) NOT NULL,
  title VARCHAR(255) NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  updated_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  deleted_at DATETIME(6) NULL,
  is_active TINYINT(1) AS (IF(deleted_at IS NULL, 1, 0)) STORED,
  version INT UNSIGNED NOT NULL DEFAULT 0,
  PRIMARY KEY (id),
  UNIQUE KEY uk_drawer_title_active (title, is_active),
  KEY idx_drawer_deleted_at (deleted_at),
  KEY idx_drawer_updated_at_id (updated_at, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE IF NOT EXISTS drawer_payload (
  drawer_id BINARY(16) NOT NULL,
  vector_json JSON NOT NULL,
  PRIMARY KEY (drawer_id),
  CONSTRAINT fk_drawer_payload__drawer
    FOREIGN KEY (drawer_id) REFERENCES drawer(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

